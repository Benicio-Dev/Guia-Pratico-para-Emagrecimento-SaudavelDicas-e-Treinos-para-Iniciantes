# E-book Landing Page Premium - Plugin WordPress

Um plugin WordPress profissional que integra uma Landing Page sofisticada para captura de leads e venda de e-books, com formulário customizado e banco de dados integrado.

## 📋 Características

- ✅ Landing Page responsiva e de alta conversão
- ✅ Formulário de captura de leads com validação
- ✅ Banco de dados integrado (MySQL)
- ✅ Painel de administração para gerenciar leads
- ✅ Design premium com paleta de cores sofisticada
- ✅ Totalmente customizável
- ✅ Compatível com WordPress 5.0+

## 🚀 Instalação

### Método 1: Upload via WordPress

1. Faça download do arquivo `ebook-lp-plugin.zip`
2. Acesse o painel do WordPress
3. Vá para **Plugins > Adicionar Novo**
4. Clique em **Fazer upload de plugin**
5. Selecione o arquivo `ebook-lp-plugin.zip`
6. Clique em **Instalar Agora**
7. Após a instalação, clique em **Ativar Plugin**

### Método 2: Upload via FTP

1. Descompacte o arquivo `ebook-lp-plugin.zip`
2. Faça upload da pasta `ebook-lp-plugin` para `/wp-content/plugins/`
3. Acesse o painel do WordPress
4. Vá para **Plugins**
5. Localize **E-book Landing Page Premium**
6. Clique em **Ativar**

## 📖 Como Usar

### Exibir a Landing Page

Para exibir a Landing Page em uma página do WordPress, use o seguinte shortcode:

```
[ebook_lp]
```

**Exemplo:**
1. Crie uma nova página no WordPress
2. Adicione o shortcode `[ebook_lp]` no editor
3. Publique a página

### Gerenciar Leads

Após o plugin estar ativado, um novo menu aparecerá no painel do WordPress:

- **E-book LP > Leads** - Visualize todos os leads capturados
- **E-book LP > Pedidos** - Visualize todos os pedidos
- **E-book LP > Configurações** - Informações do plugin

#### Ações com Leads

- **Atualizar Status** - Altere o status do lead (Novo, Contatado, Convertido, Desinscrever)
- **Deletar** - Remova um lead do banco de dados

## 🛠️ Configurações

### Tabelas do Banco de Dados

O plugin cria automaticamente duas tabelas no banco de dados:

- **wp_ebook_lp_leads** - Armazena leads capturados
- **wp_ebook_lp_orders** - Armazena pedidos/vendas

### Campos de Leads

| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | int | ID único do lead |
| name | varchar | Nome do lead |
| email | varchar | E-mail do lead |
| source | varchar | Fonte de captura (padrão: landing_page) |
| status | varchar | Status (new, contacted, converted, unsubscribed) |
| created_at | datetime | Data de criação |
| updated_at | datetime | Data de atualização |

## 🎨 Customização

### Modificar Textos

Edite o arquivo `templates/landing-page.php` para alterar textos, títulos e descrições.

### Modificar Cores

Edite o arquivo `assets/css/style.css` e procure pela seção `:root` para alterar as cores:

```css
:root {
    --primary-color: #d97706;      /* Cor primária (ouro) */
    --dark-color: #1f2937;         /* Cor escura */
    --light-bg: #f9fafb;           /* Fundo claro */
}
```

### Adicionar Campos ao Formulário

Edite o arquivo `templates/landing-page.php` e adicione novos campos no formulário:

```html
<div class="ebook-lp-form-group">
    <label for="ebook-lp-phone" class="ebook-lp-form-label">Seu Telefone</label>
    <input 
        type="tel" 
        id="ebook-lp-phone" 
        name="phone" 
        placeholder="(11) 99999-9999"
        class="ebook-lp-form-input"
    >
</div>
```

## 🔒 Segurança

- Todos os dados são sanitizados e validados
- Nonce tokens para proteção contra CSRF
- Prepared statements para proteção contra SQL injection
- Verificação de permissões de usuário

## 📊 Estrutura de Arquivos

```
ebook-lp-plugin/
├── ebook-lp-plugin.php          # Arquivo principal do plugin
├── README.md                     # Este arquivo
├── includes/
│   ├── class-ebook-lp-plugin.php
│   ├── class-ebook-lp-database.php
│   └── class-ebook-lp-shortcode.php
├── admin/
│   ├── class-ebook-lp-admin.php
│   └── css/
│       └── admin-style.css
├── assets/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── script.js
│   └── images/
└── templates/
    └── landing-page.php
```

## 🐛 Troubleshooting

### O plugin não aparece no painel

- Verifique se o arquivo `ebook-lp-plugin.php` está na raiz da pasta do plugin
- Verifique se o header do plugin está correto
- Tente desativar e reativar o plugin

### O formulário não funciona

- Verifique se o jQuery está carregado
- Verifique o console do navegador (F12) para erros
- Verifique se o nonce está sendo gerado corretamente

### Leads não estão sendo salvos

- Verifique se as tabelas foram criadas (painel > E-book LP > Configurações)
- Verifique se o usuário tem permissão para criar posts
- Verifique os logs do WordPress em `/wp-content/debug.log`

## 📞 Suporte

Para dúvidas ou problemas, entre em contato através do painel de administração do WordPress.

## 📄 Licença

Este plugin é fornecido como está. Use por sua conta e risco.

## 👨‍💻 Desenvolvido por

**Manus AI** - Transformando ideias em realidade digital

---

**Versão:** 1.0.0  
**Compatibilidade:** WordPress 5.0+  
**Última atualização:** 2024
