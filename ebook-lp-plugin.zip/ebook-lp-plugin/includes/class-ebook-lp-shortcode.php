<?php
/**
 * Shortcode handler class
 */

class Ebook_LP_Shortcode {
    
    public function register() {
        add_shortcode('ebook_lp', array($this, 'render_landing_page'));
    }
    
    public function render_landing_page($atts) {
        ob_start();
        include EBOOK_LP_PLUGIN_DIR . 'templates/landing-page.php';
        return ob_get_clean();
    }
}
