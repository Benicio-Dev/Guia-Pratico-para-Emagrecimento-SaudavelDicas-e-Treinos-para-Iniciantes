<?php
/**
 * Database management class
 */

class Ebook_LP_Database {
    
    private $leads_table;
    private $orders_table;
    
    public function __construct() {
        global $wpdb;
        $this->leads_table = $wpdb->prefix . 'ebook_lp_leads';
        $this->orders_table = $wpdb->prefix . 'ebook_lp_orders';
    }
    
    public function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Create leads table
        $leads_sql = "CREATE TABLE IF NOT EXISTS {$this->leads_table} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            email varchar(320) NOT NULL UNIQUE,
            source varchar(64) DEFAULT 'landing_page',
            status varchar(20) DEFAULT 'new',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY email (email)
        ) $charset_collate;";
        
        // Create orders table
        $orders_sql = "CREATE TABLE IF NOT EXISTS {$this->orders_table} (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            lead_id mediumint(9) NOT NULL,
            email varchar(320) NOT NULL,
            amount int(11) NOT NULL,
            currency varchar(3) DEFAULT 'BRL',
            status varchar(20) DEFAULT 'pending',
            payment_method varchar(64),
            transaction_id varchar(255),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY lead_id (lead_id),
            KEY email (email)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($leads_sql);
        dbDelta($orders_sql);
    }
    
    public function create_lead($name, $email) {
        global $wpdb;
        
        $result = $wpdb->insert(
            $this->leads_table,
            array(
                'name' => $name,
                'email' => $email,
                'source' => 'landing_page',
                'status' => 'new'
            ),
            array('%s', '%s', '%s', '%s')
        );
        
        if ($result) {
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    public function get_lead_by_email($email) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->leads_table} WHERE email = %s",
            $email
        ));
    }
    
    public function get_lead_by_id($id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->leads_table} WHERE id = %d",
            $id
        ));
    }
    
    public function get_all_leads($limit = 50, $offset = 0) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->leads_table} ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $limit,
            $offset
        ));
    }
    
    public function get_leads_count() {
        global $wpdb;
        
        return $wpdb->get_var("SELECT COUNT(*) FROM {$this->leads_table}");
    }
    
    public function update_lead_status($id, $status) {
        global $wpdb;
        
        return $wpdb->update(
            $this->leads_table,
            array('status' => $status),
            array('id' => $id),
            array('%s'),
            array('%d')
        );
    }
    
    public function delete_lead($id) {
        global $wpdb;
        
        return $wpdb->delete(
            $this->leads_table,
            array('id' => $id),
            array('%d')
        );
    }
    
    public function create_order($lead_id, $email, $amount) {
        global $wpdb;
        
        $result = $wpdb->insert(
            $this->orders_table,
            array(
                'lead_id' => $lead_id,
                'email' => $email,
                'amount' => $amount,
                'currency' => 'BRL',
                'status' => 'pending'
            ),
            array('%d', '%s', '%d', '%s', '%s')
        );
        
        if ($result) {
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    public function get_all_orders($limit = 50, $offset = 0) {
        global $wpdb;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->orders_table} ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $limit,
            $offset
        ));
    }
}
