<?php
/**
 * Main plugin class
 */

class Ebook_LP_Plugin {
    
    public function init() {
        // Register styles and scripts
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Initialize shortcodes
        $shortcode = new Ebook_LP_Shortcode();
        $shortcode->register();
        
        // Initialize admin
        if (is_admin()) {
            $admin = new Ebook_LP_Admin();
            $admin->init();
        }
        
        // Register AJAX handlers
        add_action('wp_ajax_nopriv_ebook_lp_capture_lead', array($this, 'handle_lead_capture'));
        add_action('wp_ajax_ebook_lp_capture_lead', array($this, 'handle_lead_capture'));
    }
    
    public function enqueue_frontend_assets() {
        // Enqueue Google Fonts
        wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700;800&display=swap');
        
        // Enqueue main CSS
        wp_enqueue_style(
            'ebook-lp-style',
            EBOOK_LP_PLUGIN_URL . 'assets/css/style.css',
            array(),
            EBOOK_LP_PLUGIN_VERSION
        );
        
        // Enqueue main JS
        wp_enqueue_script(
            'ebook-lp-script',
            EBOOK_LP_PLUGIN_URL . 'assets/js/script.js',
            array('jquery'),
            EBOOK_LP_PLUGIN_VERSION,
            true
        );
        
        // Localize script with AJAX URL
        wp_localize_script('ebook-lp-script', 'ebookLP', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ebook_lp_nonce')
        ));
    }
    
    public function enqueue_admin_assets() {
        wp_enqueue_style(
            'ebook-lp-admin-style',
            EBOOK_LP_PLUGIN_URL . 'admin/css/admin-style.css',
            array(),
            EBOOK_LP_PLUGIN_VERSION
        );
    }
    
    public function handle_lead_capture() {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ebook_lp_nonce')) {
            wp_send_json_error('Nonce verification failed');
        }
        
        // Sanitize input
        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        
        // Validate input
        if (empty($name) || strlen($name) < 2) {
            wp_send_json_error('Nome deve ter pelo menos 2 caracteres');
        }
        
        if (empty($email) || !is_email($email)) {
            wp_send_json_error('E-mail inválido');
        }
        
        // Check if lead already exists
        $database = new Ebook_LP_Database();
        $existing_lead = $database->get_lead_by_email($email);
        
        if ($existing_lead) {
            wp_send_json_success(array(
                'message' => 'Lead já existe em nosso banco de dados',
                'leadId' => $existing_lead->id
            ));
        }
        
        // Create new lead
        $lead_id = $database->create_lead($name, $email);
        
        if ($lead_id) {
            wp_send_json_success(array(
                'message' => 'Lead capturado com sucesso!',
                'leadId' => $lead_id
            ));
        } else {
            wp_send_json_error('Erro ao capturar lead');
        }
    }
}
