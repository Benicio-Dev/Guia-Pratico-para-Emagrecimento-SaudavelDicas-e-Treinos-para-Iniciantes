<?php
/**
 * Plugin Name: E-book Landing Page Premium
 * Plugin URI: https://ebooklpovyrue3lmanus.wordpress.com
 * Description: Landing Page profissional para captura de leads e venda de e-books com formulário customizado
 * Version: 1.0.0
 * Author: Manus AI
 * Author URI: https://manus.im
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: ebook-lp-plugin
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('EBOOK_LP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('EBOOK_LP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('EBOOK_LP_PLUGIN_VERSION', '1.0.0');

// Include required files
require_once EBOOK_LP_PLUGIN_DIR . 'includes/class-ebook-lp-plugin.php';
require_once EBOOK_LP_PLUGIN_DIR . 'includes/class-ebook-lp-database.php';
require_once EBOOK_LP_PLUGIN_DIR . 'includes/class-ebook-lp-shortcode.php';
require_once EBOOK_LP_PLUGIN_DIR . 'admin/class-ebook-lp-admin.php';

// Initialize the plugin
function ebook_lp_plugin_init() {
    $plugin = new Ebook_LP_Plugin();
    $plugin->init();
}
add_action('plugins_loaded', 'ebook_lp_plugin_init');

// Activation hook
register_activation_hook(__FILE__, function() {
    $database = new Ebook_LP_Database();
    $database->create_tables();
});

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    // Clean up if needed
});
