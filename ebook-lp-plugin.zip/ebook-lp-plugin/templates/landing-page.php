<?php
/**
 * Landing Page Template
 */
?>

<div class="ebook-lp-container">
    <!-- Navigation -->
    <nav class="ebook-lp-nav">
        <div class="ebook-lp-nav-content">
            <div class="ebook-lp-logo">
                <span class="ebook-lp-logo-icon">📚</span>
                <span class="ebook-lp-logo-text">EbookPremium</span>
            </div>
            <div class="ebook-lp-nav-links">
                <a href="#beneficios" class="ebook-lp-nav-link">Benefícios</a>
                <a href="#conteudo" class="ebook-lp-nav-link">Conteúdo</a>
                <a href="#faq" class="ebook-lp-nav-link">FAQ</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="ebook-lp-hero">
        <div class="ebook-lp-hero-content">
            <div class="ebook-lp-hero-text">
                <h1 class="ebook-lp-hero-title">
                    Pare de Sofrer com Dietas.
                </h1>
                <h2 class="ebook-lp-hero-subtitle">
                    Descubra o CÓDIGO de Emagrecimento Definitivo.
                </h2>
                
                <p class="ebook-lp-hero-description">
                    A ciência por trás do seu metabolismo, revelada em um método simples e prático. <strong>Emagreça de forma permanente, sem frustração e sem cortar o que você ama.</strong>
                </p>

                <div class="ebook-lp-cta-buttons">
                    <button class="ebook-lp-btn ebook-lp-btn-primary" onclick="document.getElementById('ebook-lp-form').scrollIntoView({behavior: 'smooth'})">
                        Baixe o Capítulo Grátis
                    </button>
                    <button class="ebook-lp-btn ebook-lp-btn-secondary">
                        Quero o E-book Completo
                    </button>
                </div>

                <div class="ebook-lp-guarantee">
                    <span class="ebook-lp-guarantee-icon">🛡️</span>
                    <span>Garantia incondicional de 7 dias. Sem risco.</span>
                </div>
            </div>

            <div class="ebook-lp-hero-image">
                <div class="ebook-lp-mockup">
                    <div class="ebook-lp-mockup-inner">
                        <span class="ebook-lp-mockup-icon">📖</span>
                        <h3>O Código</h3>
                        <p>Emagrecimento Definitivo</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Problem Section -->
    <section class="ebook-lp-problem">
        <div class="ebook-lp-section-content">
            <h2 class="ebook-lp-section-title">A Culpa Não é Sua.</h2>
            <p class="ebook-lp-section-description">
                Você já tentou de tudo: dietas restritivas, horas na academia, e a balança insiste em não cooperar. A verdade é que <strong>a maioria dos métodos falha porque ignora a sua individualidade biológica.</strong>
            </p>
            <p class="ebook-lp-section-subtitle">
                Você não falha por falta de vontade, mas sim por falta de um <strong>método científico e personalizado.</strong> Chega de frustração.
            </p>

            <div class="ebook-lp-problem-grid">
                <div class="ebook-lp-problem-card">
                    <h3>Treinar Errado</h3>
                    <p>Exercícios sem planejamento só geram frustração e lesões.</p>
                </div>
                <div class="ebook-lp-problem-card">
                    <h3>Comer sem Medida</h3>
                    <p>Sem controle calórico, não há emagrecimento possível.</p>
                </div>
                <div class="ebook-lp-problem-card">
                    <h3>Dieta Pronta</h3>
                    <p>Cada corpo é único. Dietas genéricas nunca funcionam.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Solution Section -->
    <section class="ebook-lp-solution" id="conteudo">
        <div class="ebook-lp-section-content">
            <h2 class="ebook-lp-section-title">O Método Premium que Reprograma Seu Metabolismo em 7 Dias.</h2>
            <p class="ebook-lp-section-description">
                Este e-book não é mais uma dieta. É um <strong>guia completo</strong> que te ensina a calcular seu TMB, montar seu treino ideal e ajustar sua nutrição com a precisão de um engenheiro.
            </p>

            <div class="ebook-lp-features-grid">
                <div class="ebook-lp-feature">
                    <div class="ebook-lp-feature-icon">📊</div>
                    <h3>Cálculo de IMC</h3>
                    <p>Descobre seu índice de massa corporal com precisão científica.</p>
                </div>
                <div class="ebook-lp-feature">
                    <div class="ebook-lp-feature-icon">⚡</div>
                    <h3>Cálculo de TMB</h3>
                    <p>Identifica sua taxa metabólica basal real e personalizada.</p>
                </div>
                <div class="ebook-lp-feature">
                    <div class="ebook-lp-feature-icon">💪</div>
                    <h3>Construção de Treinos</h3>
                    <p>Monta treinos específicos para o seu corpo e objetivo.</p>
                </div>
                <div class="ebook-lp-feature">
                    <div class="ebook-lp-feature-icon">🍎</div>
                    <h3>Guia de Nutrição</h3>
                    <p>Ajusta alimentação com matemática simples e eficaz.</p>
                </div>
                <div class="ebook-lp-feature">
                    <div class="ebook-lp-feature-icon">📅</div>
                    <h3>Planner Semanal</h3>
                    <p>Organiza sua semana com precisão e praticidade.</p>
                </div>
                <div class="ebook-lp-feature">
                    <div class="ebook-lp-feature-icon">✅</div>
                    <h3>Manual de Metabolismo</h3>
                    <p>Entende como seu corpo funciona de verdade.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Lead Capture Form -->
    <section class="ebook-lp-form-section" id="ebook-lp-form">
        <div class="ebook-lp-section-content">
            <h2 class="ebook-lp-section-title">Comece Sua Transformação Hoje</h2>
            <p class="ebook-lp-section-description">
                Receba o primeiro capítulo grátis + checklist exclusivo diretamente no seu e-mail.
            </p>

            <div class="ebook-lp-form-card">
                <form id="ebook-lp-lead-form" class="ebook-lp-form">
                    <div class="ebook-lp-form-group">
                        <label for="ebook-lp-name" class="ebook-lp-form-label">Seu Nome</label>
                        <input 
                            type="text" 
                            id="ebook-lp-name" 
                            name="name" 
                            placeholder="João Silva"
                            class="ebook-lp-form-input"
                            required
                        >
                    </div>
                    <div class="ebook-lp-form-group">
                        <label for="ebook-lp-email" class="ebook-lp-form-label">Seu E-mail</label>
                        <input 
                            type="email" 
                            id="ebook-lp-email" 
                            name="email" 
                            placeholder="seu@email.com"
                            class="ebook-lp-form-input"
                            required
                        >
                    </div>
                    <button type="submit" class="ebook-lp-btn ebook-lp-btn-primary ebook-lp-btn-block">
                        Receber Capítulo Grátis Agora
                    </button>
                    <p class="ebook-lp-form-disclaimer">
                        Sem spam. Seus dados estão seguros conosco.
                    </p>
                </form>
                <div id="ebook-lp-form-success" class="ebook-lp-form-success" style="display:none;">
                    <div class="ebook-lp-success-icon">✅</div>
                    <h3>Sucesso!</h3>
                    <p>Verifique seu e-mail para receber o capítulo grátis.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Offer Section -->
    <section class="ebook-lp-offer">
        <div class="ebook-lp-section-content">
            <h2 class="ebook-lp-section-title">Transformação Imediata. Investimento Mínimo.</h2>

            <div class="ebook-lp-offer-card">
                <div class="ebook-lp-offer-price">
                    <span class="ebook-lp-offer-old-price">R$ 197,00</span>
                    <span class="ebook-lp-offer-new-price">R$ 49,90</span>
                    <span class="ebook-lp-offer-savings">Economia de 75%</span>
                </div>

                <div class="ebook-lp-offer-benefits">
                    <h3>O que você recebe:</h3>
                    <ul class="ebook-lp-benefits-list">
                        <li>✓ Método completo de emagrecimento</li>
                        <li>✓ Cálculos personalizados para seu corpo</li>
                        <li>✓ Planner de treinos e alimentação</li>
                        <li>✓ Suporte por 30 dias</li>
                        <li>✓ Bônus: 3 Receitas Exclusivas</li>
                        <li>✓ Bônus: Guia de Suplementação</li>
                    </ul>
                </div>

                <button class="ebook-lp-btn ebook-lp-btn-primary ebook-lp-btn-block">
                    Garantir Minha Vaga Agora
                </button>

                <div class="ebook-lp-offer-guarantee">
                    <p class="ebook-lp-offer-guarantee-title">GARANTIA DE 7 DIAS</p>
                    <p class="ebook-lp-offer-guarantee-text">
                        Você tem 7 dias para testar. Não gostou, não paga. Sem perguntas.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="ebook-lp-testimonials" id="beneficios">
        <div class="ebook-lp-section-content">
            <h2 class="ebook-lp-section-title">Resultados Reais de Pessoas Reais</h2>

            <div class="ebook-lp-testimonials-grid">
                <div class="ebook-lp-testimonial">
                    <div class="ebook-lp-testimonial-rating">★★★★★</div>
                    <p class="ebook-lp-testimonial-text">"Finalmente entendi como meu corpo funciona. O método é simples e funciona!"</p>
                    <div class="ebook-lp-testimonial-author">
                        <p class="ebook-lp-testimonial-name">Maria Silva</p>
                        <p class="ebook-lp-testimonial-result">Perdeu 12kg em 3 meses</p>
                    </div>
                </div>

                <div class="ebook-lp-testimonial">
                    <div class="ebook-lp-testimonial-rating">★★★★★</div>
                    <p class="ebook-lp-testimonial-text">"Não imaginava que era tão fácil. Recomendo para todos meus amigos."</p>
                    <div class="ebook-lp-testimonial-author">
                        <p class="ebook-lp-testimonial-name">João Santos</p>
                        <p class="ebook-lp-testimonial-result">Ganhou massa e perdeu gordura</p>
                    </div>
                </div>

                <div class="ebook-lp-testimonial">
                    <div class="ebook-lp-testimonial-rating">★★★★★</div>
                    <p class="ebook-lp-testimonial-text">"Mudou minha vida. Agora tenho energia e confiança que nunca tive."</p>
                    <div class="ebook-lp-testimonial-author">
                        <p class="ebook-lp-testimonial-name">Ana Costa</p>
                        <p class="ebook-lp-testimonial-result">Transformação completa em 6 meses</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="ebook-lp-faq" id="faq">
        <div class="ebook-lp-section-content">
            <h2 class="ebook-lp-section-title">Perguntas Frequentes</h2>

            <div class="ebook-lp-faq-list">
                <div class="ebook-lp-faq-item">
                    <h3 class="ebook-lp-faq-question">Quanto tempo leva para ver resultados?</h3>
                    <p class="ebook-lp-faq-answer">A maioria dos clientes relata mudanças visíveis em 2-3 semanas. Resultados significativos geralmente aparecem em 4-6 semanas.</p>
                </div>

                <div class="ebook-lp-faq-item">
                    <h3 class="ebook-lp-faq-question">Preciso ir à academia?</h3>
                    <p class="ebook-lp-faq-answer">Não obrigatoriamente. O método inclui opções de treinos para casa e academia. Você escolhe o que funciona melhor para você.</p>
                </div>

                <div class="ebook-lp-faq-item">
                    <h3 class="ebook-lp-faq-question">E se eu não gostar?</h3>
                    <p class="ebook-lp-faq-answer">Você tem 7 dias para testar completamente. Se não estiver satisfeito, devolvemos 100% do seu dinheiro, sem perguntas.</p>
                </div>

                <div class="ebook-lp-faq-item">
                    <h3 class="ebook-lp-faq-question">Preciso fazer dieta restritiva?</h3>
                    <p class="ebook-lp-faq-answer">Não. O método ensina como comer de forma inteligente, sem cortar alimentos que você ama. É sobre equilíbrio, não restrição.</p>
                </div>

                <div class="ebook-lp-faq-item">
                    <h3 class="ebook-lp-faq-question">Quanto tempo preciso dedicar?</h3>
                    <p class="ebook-lp-faq-answer">O método é prático. Você precisa de apenas 30 minutos por dia para os treinos e alguns minutos para planejar suas refeições.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Final CTA Section -->
    <section class="ebook-lp-final-cta">
        <div class="ebook-lp-section-content">
            <h2 class="ebook-lp-section-title">Ou continua reclamando do espelho...</h2>
            <p class="ebook-lp-final-cta-subtitle">Ou muda hoje.</p>
            <p class="ebook-lp-final-cta-description">
                A decisão é agora. Você merece uma vida melhor.
            </p>
            <button class="ebook-lp-btn ebook-lp-btn-primary">
                Transformar Minha Vida Agora
            </button>
        </div>
    </section>

    <!-- Footer -->
    <footer class="ebook-lp-footer">
        <div class="ebook-lp-footer-content">
            <div class="ebook-lp-footer-section">
                <h4>📚 EbookPremium</h4>
                <p>Transformando vidas através da educação e ciência.</p>
            </div>
            <div class="ebook-lp-footer-section">
                <h4>Produto</h4>
                <ul>
                    <li><a href="#conteudo">Sobre o E-book</a></li>
                    <li><a href="#conteudo">Conteúdo</a></li>
                    <li><a href="#conteudo">Bônus</a></li>
                </ul>
            </div>
            <div class="ebook-lp-footer-section">
                <h4>Suporte</h4>
                <ul>
                    <li><a href="#">Contato</a></li>
                    <li><a href="#">FAQ</a></li>
                    <li><a href="#">Garantia</a></li>
                </ul>
            </div>
            <div class="ebook-lp-footer-section">
                <h4>Legal</h4>
                <ul>
                    <li><a href="#">Termos de Uso</a></li>
                    <li><a href="#">Política de Privacidade</a></li>
                    <li><a href="#">LGPD</a></li>
                </ul>
            </div>
        </div>
        <div class="ebook-lp-footer-bottom">
            <p>&copy; 2024 EbookPremium. Todos os direitos reservados.</p>
        </div>
    </footer>
</div>
