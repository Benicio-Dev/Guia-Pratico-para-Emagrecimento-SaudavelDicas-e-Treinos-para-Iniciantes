<?php
/**
 * Admin class for managing leads
 */

class Ebook_LP_Admin {
    
    public function init() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'handle_admin_actions'));
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'E-book LP - Leads',
            'E-book LP',
            'manage_options',
            'ebook-lp-leads',
            array($this, 'render_leads_page'),
            'dashicons-email-alt',
            25
        );
        
        add_submenu_page(
            'ebook-lp-leads',
            'Leads',
            'Leads',
            'manage_options',
            'ebook-lp-leads',
            array($this, 'render_leads_page')
        );
        
        add_submenu_page(
            'ebook-lp-leads',
            'Pedidos',
            'Pedidos',
            'manage_options',
            'ebook-lp-orders',
            array($this, 'render_orders_page')
        );
        
        add_submenu_page(
            'ebook-lp-leads',
            'Configurações',
            'Configurações',
            'manage_options',
            'ebook-lp-settings',
            array($this, 'render_settings_page')
        );
    }
    
    public function handle_admin_actions() {
        // Handle delete lead
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
            if (current_user_can('manage_options') && check_admin_referer('ebook_lp_nonce')) {
                $database = new Ebook_LP_Database();
                $database->delete_lead(intval($_GET['id']));
                wp_safe_remote_post(admin_url('admin.php?page=ebook-lp-leads'));
            }
        }
        
        // Handle update lead status
        if (isset($_POST['action']) && $_POST['action'] === 'update_status' && isset($_POST['id'])) {
            if (current_user_can('manage_options') && check_admin_referer('ebook_lp_nonce')) {
                $database = new Ebook_LP_Database();
                $database->update_lead_status(intval($_POST['id']), sanitize_text_field($_POST['status']));
            }
        }
    }
    
    public function render_leads_page() {
        if (!current_user_can('manage_options')) {
            wp_die('Acesso negado');
        }
        
        $database = new Ebook_LP_Database();
        $page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $leads = $database->get_all_leads($limit, $offset);
        $total_leads = $database->get_leads_count();
        $total_pages = ceil($total_leads / $limit);
        
        ?>
        <div class="wrap">
            <h1>E-book LP - Leads Capturados</h1>
            
            <div class="ebook-lp-stats">
                <div class="stat-box">
                    <span class="stat-number"><?php echo $total_leads; ?></span>
                    <span class="stat-label">Total de Leads</span>
                </div>
            </div>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Status</th>
                        <th>Data de Captura</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($leads): ?>
                        <?php foreach ($leads as $lead): ?>
                            <tr>
                                <td><?php echo esc_html($lead->id); ?></td>
                                <td><?php echo esc_html($lead->name); ?></td>
                                <td><?php echo esc_html($lead->email); ?></td>
                                <td>
                                    <form method="post" style="display:inline;">
                                        <?php wp_nonce_field('ebook_lp_nonce'); ?>
                                        <input type="hidden" name="action" value="update_status">
                                        <input type="hidden" name="id" value="<?php echo $lead->id; ?>">
                                        <select name="status" onchange="this.form.submit();">
                                            <option value="new" <?php selected($lead->status, 'new'); ?>>Novo</option>
                                            <option value="contacted" <?php selected($lead->status, 'contacted'); ?>>Contatado</option>
                                            <option value="converted" <?php selected($lead->status, 'converted'); ?>>Convertido</option>
                                            <option value="unsubscribed" <?php selected($lead->status, 'unsubscribed'); ?>>Desinscrever</option>
                                        </select>
                                    </form>
                                </td>
                                <td><?php echo esc_html($lead->created_at); ?></td>
                                <td>
                                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ebook-lp-leads&action=delete&id=' . $lead->id), 'ebook_lp_nonce'); ?>" 
                                       onclick="return confirm('Tem certeza que deseja deletar este lead?');"
                                       class="button button-small button-link-delete">Deletar</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align:center;">Nenhum lead capturado ainda</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <?php if ($total_pages > 1): ?>
                <div class="tablenav bottom">
                    <div class="tablenav-pages">
                        <?php
                        echo paginate_links(array(
                            'base' => admin_url('admin.php?page=ebook-lp-leads&paged=%#%'),
                            'format' => '',
                            'prev_text' => '&laquo; Anterior',
                            'next_text' => 'Próxima &raquo;',
                            'total' => $total_pages,
                            'current' => $page
                        ));
                        ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    public function render_orders_page() {
        if (!current_user_can('manage_options')) {
            wp_die('Acesso negado');
        }
        
        $database = new Ebook_LP_Database();
        $page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $orders = $database->get_all_orders($limit, $offset);
        
        ?>
        <div class="wrap">
            <h1>E-book LP - Pedidos</h1>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>E-mail</th>
                        <th>Valor</th>
                        <th>Status</th>
                        <th>Data do Pedido</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($orders): ?>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?php echo esc_html($order->id); ?></td>
                                <td><?php echo esc_html($order->email); ?></td>
                                <td>R$ <?php echo number_format($order->amount / 100, 2, ',', '.'); ?></td>
                                <td><?php echo esc_html($order->status); ?></td>
                                <td><?php echo esc_html($order->created_at); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align:center;">Nenhum pedido registrado ainda</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die('Acesso negado');
        }
        
        ?>
        <div class="wrap">
            <h1>E-book LP - Configurações</h1>
            
            <div class="ebook-lp-settings">
                <h2>Como usar a Landing Page</h2>
                <p>Para exibir a Landing Page em uma página do WordPress, use o seguinte shortcode:</p>
                <code style="background: #f5f5f5; padding: 10px; display: block; margin: 10px 0;">[ebook_lp]</code>
                
                <h2>Informações do Plugin</h2>
                <ul>
                    <li><strong>Versão:</strong> 1.0.0</li>
                    <li><strong>Autor:</strong> Manus AI</li>
                    <li><strong>Tabela de Leads:</strong> wp_ebook_lp_leads</li>
                    <li><strong>Tabela de Pedidos:</strong> wp_ebook_lp_orders</li>
                </ul>
                
                <h2>Suporte</h2>
                <p>Para dúvidas ou suporte, entre em contato através do painel de administração do WordPress.</p>
            </div>
        </div>
        <?php
    }
}
