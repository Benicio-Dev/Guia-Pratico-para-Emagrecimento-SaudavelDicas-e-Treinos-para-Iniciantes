/**
 * E-book Landing Page JavaScript
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // Initialize the landing page
        initLandingPage();
    });

    function initLandingPage() {
        // Handle form submission
        $('#ebook-lp-lead-form').on('submit', function(e) {
            e.preventDefault();
            captureLead();
        });

        // Add smooth scrolling for navigation links
        $('a[href^="#"]').on('click', function(e) {
            e.preventDefault();
            var target = $(this.getAttribute('href'));
            if (target.length) {
                $('html, body').stop().animate({
                    scrollTop: target.offset().top - 100
                }, 1000);
            }
        });

        // Add page class to body
        $('body').addClass('ebook-lp-page');
    }

    function captureLead() {
        var form = $('#ebook-lp-lead-form');
        var name = $('#ebook-lp-name').val().trim();
        var email = $('#ebook-lp-email').val().trim();

        // Validate
        if (!name || name.length < 2) {
            showNotification('Nome deve ter pelo menos 2 caracteres', 'error');
            return;
        }

        if (!isValidEmail(email)) {
            showNotification('E-mail inválido', 'error');
            return;
        }

        // Disable submit button
        var submitBtn = form.find('button[type="submit"]');
        var originalText = submitBtn.text();
        submitBtn.prop('disabled', true).text('Enviando...');

        // Send AJAX request
        $.ajax({
            url: ebookLP.ajaxUrl,
            type: 'POST',
            data: {
                action: 'ebook_lp_capture_lead',
                nonce: ebookLP.nonce,
                name: name,
                email: email
            },
            success: function(response) {
                if (response.success) {
                    // Show success message
                    form.hide();
                    $('#ebook-lp-form-success').show();
                    showNotification('Lead capturado com sucesso! Verifique seu e-mail.', 'success');

                    // Reset form after 3 seconds
                    setTimeout(function() {
                        form.show();
                        $('#ebook-lp-form-success').hide();
                        form[0].reset();
                        submitBtn.prop('disabled', false).text(originalText);
                    }, 3000);
                } else {
                    showNotification(response.data || 'Erro ao capturar lead', 'error');
                    submitBtn.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                showNotification('Erro ao capturar lead. Tente novamente.', 'error');
                submitBtn.prop('disabled', false).text(originalText);
            }
        });
    }

    function isValidEmail(email) {
        var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    function showNotification(message, type) {
        // Create notification element
        var notificationClass = type === 'success' ? 'ebook-lp-notification-success' : 'ebook-lp-notification-error';
        var notification = $('<div class="ebook-lp-notification ' + notificationClass + '">' + message + '</div>');

        // Add to page
        $('body').append(notification);

        // Show notification
        notification.fadeIn(300);

        // Remove after 3 seconds
        setTimeout(function() {
            notification.fadeOut(300, function() {
                $(this).remove();
            });
        }, 3000);
    }

})(jQuery);

// Add notification styles dynamically
(function() {
    var style = document.createElement('style');
    style.textContent = `
        .ebook-lp-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            font-weight: 500;
            z-index: 9999;
            max-width: 400px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            animation: slideIn 0.3s ease;
        }

        .ebook-lp-notification-success {
            background: #10b981;
            color: white;
        }

        .ebook-lp-notification-error {
            background: #ef4444;
            color: white;
        }

        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @media (max-width: 768px) {
            .ebook-lp-notification {
                left: 10px;
                right: 10px;
                max-width: none;
            }
        }
    `;
    document.head.appendChild(style);
})();
